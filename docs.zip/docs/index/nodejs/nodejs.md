# 将自己的nodeJS项目分享到npm上
## 一、在npm官网上注册一个账号：
><a href='https://www.npmjs.com'>npm官网链接</a><br/>
::: tip 提示
注意注册完账号记得绑定邮箱，如果没有绑定邮箱的话无法上传npm包。
:::


## 二、生成package.json文件
1. 在项目根目录文件下打开控制台，使用```npm init```生成```package.json```文件。下面是打开控制台的几种方法。<br/>
<span style="font-weight: 900">第一种：</span>在项目中按住```shift+右键```，点击```在此处打开命令窗口```。<br/>
<span style="font-weight: 900">第二种：</span>在项目中输入cmd敲回车
![在项目中输入cmd](https://upload-images.jianshu.io/upload_images/13479263-02579d911c8d15d5.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)<br/>
<span style="font-weight: 900">第三种：</span>使用按住电脑上的```window+r```，进入如下图所示，然后输入```cmd```，点击确定进入控制台
![window+r](https://upload-images.jianshu.io/upload_images/13479263-5fe2bb4e1b74dfc1.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)<br/>
<span style="font-weight: 900">第四种：</span>在开始菜单里输入cmd，运行控制台，不过进入控制台后，如果需要到你的项目中，则需要使用命令```cd “项目所在文件夹路径”```**注意命令cd和项目所在文件夹路径中间有个空格**进入项目文件夹下
![开始菜单里输入cmd](https://upload-images.jianshu.io/upload_images/13479263-67aab8b2ba583b89.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)<br/>
下图为上传生成pack.json文件的一个示列：
![使用npm init生成package.json文件](https://upload-images.jianshu.io/upload_images/13479263-612ab592781e0435.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
## 三、在项目中添加用户
```package.json```文件生成好了以后，使用命令```npm adduser```在项目中添加用户信息
![为项目添加用户信息](https://upload-images.jianshu.io/upload_images/13479263-9d069163b3ceab1b.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
## 四、将项目发布至npm上
1. 在给项目添加完用户信息以后，使用命令```npm publish```将自己的项目发布至npm上。
![将项目发布至npm上](https://upload-images.jianshu.io/upload_images/13479263-48453b1590d61991.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
2. 发布成功以后就可以在npm官网上查到你的包了。
![查看上传包](https://upload-images.jianshu.io/upload_images/13479263-63cc0c91de8c1185.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
## 五、如何删除发布至npm上的包
在项目中使用命令```npm unpublish --force```即可
![删除上传包](https://upload-images.jianshu.io/upload_images/13479263-2889651faeab9c43.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)


