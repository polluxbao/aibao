# 使用Cmder替换cmd，让开发更高效

## 一、为什么要更换为cmder
 在做项目时，有些时候我想复制控制台上面的代码时，**cmd**有的时候复制粘贴很麻烦，**Cmder**则不会，并且**Cmder**可以分屏多开窗口，可以设置窗口颜色,字体大小，并且很多快捷键和谷歌浏览器操作类似,等等很多功能。
## 二、官网下载地址:
><a href='http://cmder.net/'>cmder网址</a><br>

### 关于下载
进入官网以后，有**mini版**和**完整版**，建议完整版，完整版功能更齐全，还可以使用```git```，下载好解压文件包以后就可以使用。
![image.png](https://upload-images.jianshu.io/upload_images/13479263-a8a6450b69cb136c.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
### Cmder界面展示
启动Cmder界面如下，当然我设置了背景色，透明度，字体样式，隐藏标签栏栏，增加底部的状态栏，以及分屏功能。
![Cmder界面展示](https://upload-images.jianshu.io/upload_images/13479263-ef580c697474880d.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
## 三、关于cmder的一些配置
### 1. 配置环境变量:
在系统属性里面配置环境变量，将```Cmder.exe```所在文件路径添加至```Path```里
![image.png](https://upload-images.jianshu.io/upload_images/13479263-87db9162416bf29b.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
![image.png](https://upload-images.jianshu.io/upload_images/13479263-e2f1e706bf445886.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
### 2. 配置右键快捷启动:
以管理员身份打开```cmd```，执行以下命令即可，完了以后在任意地方点击右键即可使用cmder
```
// 设置任意地方鼠标右键启动Cmder
Cmder.exe /REGISTER ALL
```
![鼠标右键启动Cmder](https://upload-images.jianshu.io/upload_images/13479263-46f0ec91b15cd4e5.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
### 3. 界面效果的设置
首先使用```windows+alt+p```进入界面设置
背景色设置
![image.png](https://upload-images.jianshu.io/upload_images/13479263-cd9f51de6a6464e6.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
字体设置
![image.png](https://upload-images.jianshu.io/upload_images/13479263-5d90f5c67e4be767.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
背景透明度
![image.png](https://upload-images.jianshu.io/upload_images/13479263-7b1f5ba987021346.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
隐藏标签栏
![image.png](https://upload-images.jianshu.io/upload_images/13479263-5ef33c025ac01d61.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
显示底部状态栏
![image.png](https://upload-images.jianshu.io/upload_images/13479263-be5705ebc73910bf.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
将Cmder默认的命令提示符```"λ"```改为```“$”```，
在```cmder\vendor\clink```中的```clink.lua```内做如下修改"λ"替换成"$"
![image.png](https://upload-images.jianshu.io/upload_images/13479263-7de88efa37a7999b.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
## 四、关于Cmder的一些常用快捷键
>Tab	自动路径补全
<p>Ctrl+T	建立新页签</p>
<p>Ctrl+W	关闭页签</p>
<p>Ctrl+Tab	切换页签</p>
<p>Alt+F4	关闭所有页签</p>
<p>Alt+Shift+1	开启cmd.exe</p>
<p>Alt+Shift+2	开启powershell.exe</p>
<p>Alt+Shift+3	开启powershell.exe (系统管理员权限)</p>
<p>Ctrl+1	快速切换到第1个页签</p>
<p>Ctrl+n	快速切换到第n个页签( n值无上限)</p>
<p>Alt + enter	切换到全屏状态</p>
<p>Ctr+r	历史命令搜索</p>
<p>Win快捷键	含义</p>
<p>Tab	自动路径补全</p>
<p>Ctrl+T	建立新页签</p>
<p>Ctrl+W	关闭页签</p>
<p>Ctrl+Tab	切换页签</p>
<p>Alt+F4	关闭所有页签</p>
<p>Alt+Shift+1	开启cmd.exe</p>
<p>Alt+Shift+2	开启powershell.exe</p>
<p>Alt+Shift+3	开启powershell.exe (系统管理员权限)</p>
<p>Ctrl+n	快速切换到第n个页签( n值无上限)</p>
<p>Alt + enter	切换到全屏状态</p>
<p>Ctr+r	历史命令搜索</p>
<p>Win+Alt+P	开启工具选项视窗</p>













