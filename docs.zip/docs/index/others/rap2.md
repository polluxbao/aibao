# 使用RAP2模拟假数据实现前后端分离
## 一、为什么使用RAP2
&nbsp;　　在一个项目的开发中，在页面需要使用大量数据进行渲染生成前，后端开发人员的接口可能还没有写完, 当前端没有后端数据支持的情况下，我们使用```mock.js```(mock.js用于生成随机数据，拦截ajax请求)模拟假数据，实现前后端分离。开发中我们也可以使用```RAP2```(这里面生成的数据基于mock.js)在线模拟假数据。
## 二、关于RAP2的一些学习网址
> <a href='http://mockjs.com/'>mock.js网址</a><br>
<a href='http://rap2.taobao.org/'>RAP2网址</a><br>
<a href='https://github.com/thx/rap2-delos'>RAP2官方文档</a><br>
<a href='https://github.com/nuysoft/Mock/wiki/Syntax-Specification'>mock.js语法规范文档</a>

## 三、与RAP2同类型的jsonplaceholder
&nbsp;　　jsonplaceholder也是模拟假数据，和RAP2差别是jsonplaceholder模拟出来的假数据只有固定值。
> <a href='http://jsonplaceholder.typicode.com/'>jsonplaceholder网址</a>

## 四、RAP2使用步骤
1. 进入RAP2网址账号注册成功以后，我们首先创建一个项目仓库，如下图所示：
![pic_1](https://upload-images.jianshu.io/upload_images/13479263-42662d6b0c93a5af.png?imageMogr2/auto-orient/strip%7CimageView2/2/)
![pic_2](https://upload-images.jianshu.io/upload_images/13479263-046c84f4cd106ad1.png?imageMogr2/auto-orient/strip%7CimageView2/2/)
2. 仓库建好以后，我们进入仓库，点击新建接口
![pic_3](https://upload-images.jianshu.io/upload_images/13479263-7af801f3120012e6.png?imageMogr2/auto-orient/strip%7CimageView2/2/)
![pic_4](https://upload-images.jianshu.io/upload_images/13479263-a071bbd4935b0a5c.png?imageMogr2/auto-orient/strip%7CimageView2/2/)
3. 新建接口完毕以后，我们可以看到如下图所示，我们点击商品列表，右图可以根据设置请求参数，和响应内容（点击绿色的编辑按钮），右图中还有一个地址，点击这个地址，进入以后内容如图pic_6所示
![pic_5](https://upload-images.jianshu.io/upload_images/13479263-67bad0a59894603a.png?imageMogr2/auto-orient/strip%7CimageView2/2/)
![pic_6](https://upload-images.jianshu.io/upload_images/13479263-8a77f08dcb46e2ab.png?imageMogr2/auto-orient/strip%7CimageView2/2/)
4. 接下来设置请求参数和响应参数，这里以响应参数举例，点击响应内容右边的新建创建响应属性，如下图所示：
![pic_7](https://upload-images.jianshu.io/upload_images/13479263-00358db2f1ba3387.png?imageMogr2/auto-orient/strip%7CimageView2/2/)
5. 根据所创建的数据类型不同，左侧会出现pic_8所示“+”号，点击“+”号可以向其内部添加属性，
图pic_8为按照填写的生成规则生成的响应数据。【```生成规则```有7中格式，关于生成规则可以查看文章开头的链接mock.js语法规范文档】，例如图pic_8中```data```属性的生成规则为9，表示生成9个元素。```id```属性的生成规则为1-9999，表示生成1-9999的随机数字。
![pic_8](https://upload-images.jianshu.io/upload_images/13479263-678ef11e9670bce9.png?imageMogr2/auto-orient/strip%7CimageView2/2/)
6. ```mock.js```文档中关于```mock.random```的方法在数据模板中称为『占位符』，书写格式为 ```@占位符(参数 [, 参数])```，可以用在初始值的设置中，随机生成一段内容。
![pic_9](https://upload-images.jianshu.io/upload_images/13479263-695f582b2939cc2a.png?imageMogr2/auto-orient/strip%7CimageView2/2/)

转载文章请注名出处