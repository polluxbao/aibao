module.exports = {
  dest: 'vuepress',
  locales: {
    '/': {
      lang: 'zh-CN',
      title: '@kayle',
      description: '学习，总结，温故，知新'
    }
  },
  head: [
    ['link', { rel: 'icon', href: `/logo.png` }],
    ['link', { rel: 'manifest', href: '/manifest.json' }],
    ['meta', { name: 'theme-color', content: '#3eaf7c' }],
    ['meta', { name: 'apple-mobile-web-app-capable', content: 'yes' }],
    ['meta', { name: 'apple-mobile-web-app-status-bar-style', content: 'black' }],
    ['link', { rel: 'apple-touch-icon', href: `/icons/apple-touch-icon-152x152.png` }],
    ['link', { rel: 'mask-icon', href: '/icons/safari-pinned-tab.svg', color: '#3eaf7c' }],
    ['meta', { name: 'msapplication-TileImage', content: '/icons/msapplication-icon-144x144.png' }],
    ['meta', { name: 'msapplication-TileColor', content: '#000000' }]
  ],
  serviceWorker: true,//文章更新刷新客户端网页
  theme: 'vue',
  themeConfig: {
    // 一个完整的 GitLab URL。
    // repo: 'https://github.com/1Crazy/1Crazy.github.io',
    // 自定义项目仓库链接文字
    // 默认根据 `themeConfig.repo` 中的 URL 来自动匹配是 "GitHub"/"GitLab"/"Bitbucket" 中的哪个，如果不设置时是 "Source"。
    repoLabel: 'github',
    // editLinks: true,
    docsDir: 'docs',
    //获取最后一次提交博客时间
    lastUpdated: 'Last Updated', // 最后更新时间
    displayAllHeaders: true, // 默认值：false
    // selectText: '选择语言',
    // editLinkText: '编辑此页',
    lastUpdated: '上次更新',
    locales: {
      '/': {
        label: '简体中文',
        selectText: '选择语言',
        editLinkText: '编辑此页',
        lastUpdated: '上次更新',
        nav: [
          {
            text: '博文',
            // link: '/index/HTMLCSS/'
            items: [
              { text: 'html&css', link: '/index/html-css/css.md' },
              { text: 'javascript', link: '/index/javascript/javascript.md' },
              { text: 'nodejs', link: '/index/nodejs/nodejs.md' },
              { text: '其它', link: '/index/others/rap2.md' }
            ]
          },
          {
            text: '项目总结',
            link: '/project/project.md'
          },
          {
            text: '小练习',
            link: '/practice/practice.md'
          },
          {
            text: '简书',
            link: 'https://www.jianshu.com/u/422ccfa02512'
          },
          {
            text: 'github',
            link: 'https://github.com/1Crazy/1Crazy.github.io'
          }
        ],
      },
    },
    sidebar: {
      '/index/': [
        // 侧边栏在 /index/ 目录上
        '/index/',
        {
          title: 'html&css',
          collapsable: true, // 不可折叠
          children: ['/index/html-css/css.md']
        },
        // 侧边栏在 /javascript/ 目录上
        {
          title: 'javascript',
          collapsable: true, // 不可折叠
          children: [
            '/index/javascript/javascript.md'
          ]
        },
        // 侧边栏在 /node.js/ 目录上
        {
          title: 'nodejs',
          collapsable: true, // 不可折叠
          children: [
            '/index/nodejs/nodejs.md',
            '/index/nodejs/spider.md',
          ]
        },
        // 侧边栏在 /others/ 目录上
        {
          title: '其它',
          collapsable: true, // 不可折叠
          children: [
            '/index/others/rap2.md',
            '/index/others/cmder.md',
          ]
        },
      ],
      // 侧边栏在 /practice/ 目录上
      '/practice/': [
        ['/practice/practice.md','练习'],
        ['/practice/practice1.md','练习1']
      ],
      // 侧边栏在 /project/ 目录上
      '/project/': [
        ['/project/project.md','工作总结'],
        ['/project/project1.md','工作总结1']
      ]
    },
  }
}

// function genSidebarConfig (title) {
//   return [
//     {
//       title,
//       collapsable: false, //不可折叠
//       children: [
//         '',
//         'getting-started',
//         'basic-config',
//         'assets',
//         'markdown',
//         'using-vue',
//         'custom-themes',
//         'i18n',
//         'deploy'
//       ]
//     }
//   ]
// }
