---
home: true
heroImage: /kayle.jpg
actionText: 我的文章
actionLink: /index/
footer: 王玉宏的博客| Copyright © 2018-加油，没有到不了的明天
---

<div class="features">
  <div class="feature">
    <h2>NOTE_0</h2>
    <p>觉得自己做的到和做不到，其实只在一念之间。当你感到悲哀痛苦时，最好是去学些什么东西。学习会使你永远立于不败之地。</p>
  </div>
  <div class="feature">
    <h2>NOTE_1</h2>
    <p>当你无法从一楼蹦到三楼时，不要忘记走楼梯。要记住伟大的成功往往不是一蹴而就的，必须学会分解你的目标，逐步实施。</p>
  </div>
  <div class="feature">
    <h2>NOTE_2</h2>
    <p>死亡教会人一切，如同考试之后公布的结果——虽然恍然大悟，但为时晚矣。</p>
  </div>
</div>
